package finaltest_chatsys.chatsys.service;


// 实现用户添加、修改密码、查看信息、修改信息接口
public interface UserService
{

}
