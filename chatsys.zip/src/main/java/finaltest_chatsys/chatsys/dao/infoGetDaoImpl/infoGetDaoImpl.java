package finaltest_chatsys.chatsys.dao.infoGetDaoImpl;

import finaltest_chatsys.chatsys.dao.infoGetDao;
import finaltest_chatsys.chatsys.entity.Info;

import java.util.List;
//消息获取Dao的实现类
public class infoGetDaoImpl implements infoGetDao {
    @Override
    public List<Info> getChatInfoById(String id) {
        return null;
    }

    @Override
    public List<Info> getFriendReqById(String id) {
        return null;
    }
}
