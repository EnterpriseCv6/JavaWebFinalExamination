package finaltest_chatsys.chatsys.controller;

import org.junit.Test;

import static org.junit.Assert.*;

public class WebSocketEndPointTest {

    @Test
    public void onOpen() {
    }

    @Test
    public void onClose() {
    }

    @Test
    public void onMessage() {
    }

    @Test
    public void onError() {
    }

    @Test
    public void sendMsg() {
    }

    @Test
    public void addOnlineCount() {
    }

    @Test
    public void subOnlineCount() {
    }
}